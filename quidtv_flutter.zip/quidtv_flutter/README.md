# QuidTV Flutter App

Flutter-based IPTV app — QuidTV এর হুবহু UI, MPV engine দিয়ে সব ফরম্যাট চলবে।

## Features
- ✅ **media_kit (MPV)** — `.m3u8`, `.ts`, `.mp4`, `.rtmp`, `.rtsp` সব চলে, CORS নেই
- ✅ Firebase Realtime Database থেকে চ্যানেল লোড
- ✅ Dark / Light theme
- ✅ Channel grid (3-col, 2-col, list view)
- ✅ Favorites, Recently Watched
- ✅ Search
- ✅ Banner rotator
- ✅ Notice bar
- ✅ Ads system
- ✅ Emergency stop
- ✅ Fullscreen + landscape
- ✅ Volume control + seek bar
- ✅ Fit mode (contain / cover / fill)

---

## Setup

### 1. Flutter SDK Install
```bash
# Flutter 3.10+ দরকার
flutter --version
```

### 2. Dependencies Install
```bash
cd quidtv_flutter
flutter pub get
```

### 3. Android Setup
`android/app/build.gradle` এ minSdk নিশ্চিত করুন:
```gradle
android {
    defaultConfig {
        minSdkVersion 21   // media_kit এর জন্য 21+ লাগবে
        targetSdkVersion 34
    }
}
```

### 4. iOS Setup
`ios/Podfile` এ platform নিশ্চিত করুন:
```ruby
platform :ios, '12.0'
```

তারপর:
```bash
cd ios && pod install
```

### 5. Run
```bash
# Android
flutter run

# iOS
flutter run -d "iPhone"

# Release APK
flutter build apk --release

# Release AAB (Play Store)
flutter build appbundle --release
```

---

## Firebase
Firebase config `lib/main.dart` এ আছে — QuidTV web এর মতোই।
নিজের Firebase project ব্যবহার করতে চাইলে `lib/main.dart` এ FirebaseOptions পরিবর্তন করুন।

## Player (media_kit)
MPV ইঞ্জিন ব্যবহার করে, তাই:
- কোনো CORS সমস্যা নেই
- সব ধরনের stream URL কাজ করবে
- Hardware accelerated decoding

## Folder Structure
```
lib/
├── main.dart              # Entry point + Firebase init
├── models/
│   └── channel.dart       # Channel data model
├── services/
│   ├── app_theme.dart     # Dark/Light theme
│   └── firebase_service.dart  # Firebase streams
├── screens/
│   ├── home_screen.dart   # Main screen
│   └── player_screen.dart # MPV video player
└── widgets/
    └── channel_card.dart  # Channel card UI
```
