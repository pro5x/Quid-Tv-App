class Channel {
  final String id;
  final String name;
  final String url;
  final String? logo;
  final String? category;
  final String? status;
  final bool pinned;
  final int likes;

  const Channel({
    required this.id,
    required this.name,
    required this.url,
    this.logo,
    this.category,
    this.status,
    this.pinned = false,
    this.likes = 0,
  });

  factory Channel.fromMap(String id, Map<dynamic, dynamic> map) {
    return Channel(
      id: id,
      name: map['name']?.toString() ?? 'Unknown',
      url: map['url']?.toString() ?? '',
      logo: map['logo']?.toString(),
      category: map['category']?.toString(),
      status: map['status']?.toString(),
      pinned: map['pinned'] == true,
      likes: (map['likes'] as num?)?.toInt() ?? 0,
    );
  }

  bool get isLive => status != 'offline';
}
