import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:media_kit/media_kit.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'services/app_theme.dart';
import 'screens/home_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize media_kit (MPV engine)
  MediaKit.ensureInitialized();

  // Initialize Firebase
  await Firebase.initializeApp(
    options: const FirebaseOptions(
      apiKey: 'AIzaSyBPkfzrQtrmSYrlq6abG1AKrcADqLH6LwA',
      authDomain: 'live-tv-sever.firebaseapp.com',
      databaseURL: 'https://live-tv-sever-default-rtdb.asia-southeast1.firebasedatabase.app',
      projectId: 'live-tv-sever',
      storageBucket: 'live-tv-sever.firebasestorage.app',
      messagingSenderId: '1074113866095',
      appId: '1:1074113866095:web:96aa7e3b2fb1d1618b609a',
    ),
  );

  // Status bar style
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
  ));

  runApp(const QuidTVApp());
}

class QuidTVApp extends StatefulWidget {
  const QuidTVApp({super.key});

  @override
  State<QuidTVApp> createState() => _QuidTVAppState();
}

class _QuidTVAppState extends State<QuidTVApp> {
  bool _isDark = true;

  @override
  void initState() {
    super.initState();
    _loadTheme();
  }

  Future<void> _loadTheme() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() => _isDark = prefs.getString('theme') != 'light');
  }

  Future<void> _toggleTheme() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() => _isDark = !_isDark);
    await prefs.setString('theme', _isDark ? 'dark' : 'light');
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'QuidTV',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light(),
      darkTheme: AppTheme.dark(),
      themeMode: _isDark ? ThemeMode.dark : ThemeMode.light,
      home: _SplashGate(isDark: _isDark, onThemeToggle: _toggleTheme),
    );
  }
}

// ── Splash screen then home ──
class _SplashGate extends StatefulWidget {
  final bool isDark;
  final VoidCallback onThemeToggle;
  const _SplashGate({required this.isDark, required this.onThemeToggle});

  @override
  State<_SplashGate> createState() => _SplashGateState();
}

class _SplashGateState extends State<_SplashGate> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _opacity;
  bool _done = false;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 800));
    _opacity = CurvedAnimation(parent: _ctrl, curve: Curves.easeOut);
    _ctrl.forward();
    Future.delayed(const Duration(milliseconds: 2500), () {
      if (mounted) setState(() => _done = true);
    });
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    if (_done) {
      return HomeScreen(isDark: widget.isDark, onThemeToggle: widget.onThemeToggle);
    }

    return Scaffold(
      backgroundColor: const Color(0xFF030508),
      body: Center(
        child: FadeTransition(
          opacity: _opacity,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Logo
              RichText(
                text: const TextSpan(
                  children: [
                    TextSpan(
                      text: 'QUID',
                      style: TextStyle(
                        fontSize: 42,
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                        letterSpacing: 8,
                      ),
                    ),
                    TextSpan(
                      text: 'TV',
                      style: TextStyle(
                        fontSize: 42,
                        fontWeight: FontWeight.w900,
                        color: AppTheme.red,
                        letterSpacing: 8,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 28),
              // Loading bar
              SizedBox(
                width: 180,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(3),
                  child: const LinearProgressIndicator(
                    color: AppTheme.red,
                    backgroundColor: Color(0xFF1A1A1A),
                    minHeight: 3,
                  ),
                ),
              ),
              const SizedBox(height: 14),
              const Text(
                'ULTRA HD STREAMING',
                style: TextStyle(
                  color: Color(0x55FFFFFF),
                  fontSize: 10,
                  letterSpacing: 5,
                  fontWeight: FontWeight.w400,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
