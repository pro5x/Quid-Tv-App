import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../models/channel.dart';
import '../services/app_theme.dart';

class ChannelCard extends StatelessWidget {
  final Channel channel;
  final bool isFav;
  final bool isPlaying;
  final bool isPinned;
  final String viewMode; // 'g3', 'g2', 'lst'
  final VoidCallback onTap;
  final VoidCallback onFavTap;

  const ChannelCard({
    super.key,
    required this.channel,
    required this.isFav,
    required this.isPlaying,
    required this.isPinned,
    required this.viewMode,
    required this.onTap,
    required this.onFavTap,
  });

  Widget _logo({double size = 48}) {
    if (channel.logo != null && channel.logo!.isNotEmpty) {
      return CachedNetworkImage(
        imageUrl: channel.logo!,
        width: size,
        height: size,
        fit: BoxFit.contain,
        placeholder: (_, __) => _fallback(size),
        errorWidget: (_, __, ___) => _fallback(size),
      );
    }
    return _fallback(size);
  }

  Widget _fallback(double size) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: const Color(0xFF1A2030),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Center(
        child: Text(
          channel.name.substring(0, channel.name.length >= 2 ? 2 : 1).toUpperCase(),
          style: TextStyle(
            color: Colors.white,
            fontSize: size * 0.35,
            fontWeight: FontWeight.w800,
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final cardColor = Theme.of(context).cardColor;
    final borderColor = isPlaying
        ? AppTheme.red
        : isPinned
            ? AppTheme.red2
            : Theme.of(context).dividerColor;
    final BoxShadow? shadow = isPlaying
        ? BoxShadow(
            color: AppTheme.red.withOpacity(0.22),
            blurRadius: 16,
            offset: const Offset(0, 4),
          )
        : null;

    if (viewMode == 'lst') {
      return _ListCard(
        channel: channel,
        isFav: isFav,
        isPlaying: isPlaying,
        isPinned: isPinned,
        cardColor: cardColor,
        borderColor: borderColor,
        shadow: shadow,
        logo: _logo(size: 36),
        onTap: onTap,
        onFavTap: onFavTap,
      );
    }

    // Grid card (g2 or g3)
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        decoration: BoxDecoration(
          color: isPinned ? AppTheme.red2.withOpacity(0.04) : cardColor,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: borderColor),
          boxShadow: shadow != null ? [shadow] : null,
        ),
        child: Stack(
          children: [
            Padding(
              padding: const EdgeInsets.all(9),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(child: _logo(size: viewMode == 'g2' ? 56 : 44)),
                  const SizedBox(height: 7),
                  Text(
                    channel.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                      color: Theme.of(context).textTheme.bodyLarge?.color,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Row(
                    children: [
                      Container(
                        width: 7,
                        height: 7,
                        decoration: BoxDecoration(
                          color: channel.isLive ? const Color(0xFF22C55E) : Colors.grey,
                          shape: BoxShape.circle,
                        ),
                      ),
                      const SizedBox(width: 4),
                      Expanded(
                        child: Text(
                          channel.category ?? 'General',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: 10,
                            color: Theme.of(context).textTheme.bodySmall?.color,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            // Badges
            if (isPinned)
              Positioned(
                top: 6,
                right: 6,
                child: _Badge(label: 'PINNED', color: AppTheme.red2),
              ),
            if (isPlaying)
              Positioned(
                top: 6,
                left: 6,
                child: _Badge(label: 'ON AIR', color: AppTheme.red, dot: true),
              ),
            // Fav star
            Positioned(
              bottom: 6,
              right: 6,
              child: GestureDetector(
                onTap: onFavTap,
                child: Container(
                  width: 22,
                  height: 22,
                  decoration: BoxDecoration(
                    color: isFav
                        ? AppTheme.red.withOpacity(0.12)
                        : Colors.white.withOpacity(0.06),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    Icons.star,
                    size: 13,
                    color: isFav ? AppTheme.red : Colors.grey,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ListCard extends StatelessWidget {
  final Channel channel;
  final bool isFav, isPlaying, isPinned;
  final Color cardColor, borderColor;
  final BoxShadow? shadow;
  final Widget logo;
  final VoidCallback onTap, onFavTap;

  const _ListCard({
    required this.channel,
    required this.isFav,
    required this.isPlaying,
    required this.isPinned,
    required this.cardColor,
    required this.borderColor,
    required this.shadow,
    required this.logo,
    required this.onTap,
    required this.onFavTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: cardColor,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: borderColor),
          boxShadow: shadow != null ? [shadow!] : null,
        ),
        child: Row(
          children: [
            Container(
              width: 46,
              height: 46,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.04),
                borderRadius: BorderRadius.circular(9),
              ),
              child: Center(child: logo),
            ),
            const SizedBox(width: 11),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    channel.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      color: Theme.of(context).textTheme.bodyLarge?.color,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Row(
                    children: [
                      Container(
                        width: 7,
                        height: 7,
                        decoration: BoxDecoration(
                          color: channel.isLive ? const Color(0xFF22C55E) : Colors.grey,
                          shape: BoxShape.circle,
                        ),
                      ),
                      const SizedBox(width: 4),
                      Text(
                        channel.category ?? 'General',
                        style: TextStyle(
                          fontSize: 11,
                          color: Theme.of(context).textTheme.bodySmall?.color,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            if (isPinned) const _Badge(label: 'PINNED', color: AppTheme.red2),
            if (isPlaying) const SizedBox(width: 4),
            if (isPlaying) const _Badge(label: 'ON AIR', color: AppTheme.red, dot: true),
            const SizedBox(width: 8),
            GestureDetector(
              onTap: onFavTap,
              child: Container(
                width: 28,
                height: 28,
                decoration: BoxDecoration(
                  color: isFav
                      ? AppTheme.red.withOpacity(0.12)
                      : Colors.white.withOpacity(0.06),
                  shape: BoxShape.circle,
                ),
                child: Icon(Icons.star, size: 15, color: isFav ? AppTheme.red : Colors.grey),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Badge extends StatelessWidget {
  final String label;
  final Color color;
  final bool dot;

  const _Badge({required this.label, required this.color, this.dot = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(4),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (dot) ...[
            Container(
              width: 5,
              height: 5,
              decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
            ),
            const SizedBox(width: 3),
          ],
          Text(
            label,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 8,
              fontWeight: FontWeight.w900,
              letterSpacing: 0.5,
            ),
          ),
        ],
      ),
    );
  }
}
