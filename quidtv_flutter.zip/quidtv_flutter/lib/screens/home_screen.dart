import 'dart:async';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:shimmer/shimmer.dart';
import '../models/channel.dart';
import '../services/firebase_service.dart';
import '../services/app_theme.dart';
import '../widgets/channel_card.dart';
import 'player_screen.dart';

class HomeScreen extends StatefulWidget {
  final bool isDark;
  final VoidCallback onThemeToggle;

  const HomeScreen({super.key, required this.isDark, required this.onThemeToggle});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _firebase = FirebaseService();
  final _searchCtrl = TextEditingController();

  List<Channel> _channels = [];
  List<Channel> _filtered = [];
  Set<String> _favIds = {};
  List<String> _recIds = [];
  String _category = 'all'; // all | fav | rec
  String _viewMode = 'g3';  // g3 | g2 | lst
  String? _playingId;
  bool _searching = false;
  bool _loading = true;
  bool _offline = false;
  bool _emergency = false;

  // Banner
  List<Map<String, dynamic>> _banners = [];
  int _bannerIdx = 0;
  Timer? _bannerTimer;

  // Notice
  String? _noticeText;
  bool _noticeOn = false;

  // Ads
  List<Map<String, dynamic>> _ads = [];

  StreamSubscription? _connSub;

  @override
  void initState() {
    super.initState();
    _loadPrefs();
    _listenConnectivity();
    _listenFirebase();
  }

  Future<void> _loadPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _favIds = Set<String>.from(prefs.getStringList('fav') ?? []);
      _recIds = prefs.getStringList('rec') ?? [];
      _viewMode = prefs.getString('view') ?? 'g3';
    });
  }

  Future<void> _savePrefs() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('fav', _favIds.toList());
    await prefs.setStringList('rec', _recIds);
    await prefs.setString('view', _viewMode);
  }

  void _listenConnectivity() {
    _connSub = Connectivity().onConnectivityChanged.listen((results) {
      setState(() => _offline = results.every((r) => r == ConnectivityResult.none));
    });
  }

  void _listenFirebase() {
    _firebase.channelsStream().listen((channels) {
      if (mounted) setState(() { _channels = channels; _loading = false; _applyFilter(); });
    }, onError: (_) {
      if (mounted) setState(() => _loading = false);
    });

    _firebase.bannersStream().listen((banners) {
      if (!mounted) return;
      setState(() => _banners = banners);
      _bannerTimer?.cancel();
      if (_banners.length > 1) {
        _bannerTimer = Timer.periodic(const Duration(seconds: 5), (_) {
          if (mounted) setState(() => _bannerIdx = (_bannerIdx + 1) % _banners.length);
        });
      }
    });

    _firebase.noticeStream().listen((notice) {
      if (!mounted || notice == null) return;
      setState(() {
        _noticeOn = notice['status'] != 'disabled' && (notice['text']?.toString().trim().isNotEmpty ?? false);
        _noticeText = notice['text']?.toString();
      });
    });

    _firebase.adsStream().listen((ads) {
      if (mounted) setState(() => _ads = ads);
    });

    _firebase.emergencyStream().listen((emergency) {
      if (mounted) setState(() => _emergency = emergency);
    });
  }

  void _applyFilter() {
    List<Channel> list;
    if (_searching && _searchCtrl.text.trim().isNotEmpty) {
      final q = _searchCtrl.text.trim().toLowerCase();
      list = _channels.where((c) =>
        c.name.toLowerCase().contains(q) ||
        (c.category ?? '').toLowerCase().contains(q)
      ).toList();
    } else if (_category == 'fav') {
      list = _channels.where((c) => _favIds.contains(c.id)).toList();
    } else if (_category == 'rec') {
      list = _recIds
          .map((id) => _channels.firstWhere((c) => c.id == id, orElse: () => Channel(id: '', name: '', url: '')))
          .where((c) => c.id.isNotEmpty)
          .toList();
    } else {
      list = List<Channel>.from(_channels);
    }
    setState(() => _filtered = list);
  }

  void _toggleFav(String id) {
    setState(() {
      if (_favIds.contains(id)) _favIds.remove(id); else _favIds.add(id);
    });
    _savePrefs();
    _applyFilter();
  }

  void _addRec(String id) {
    _recIds.remove(id);
    _recIds.insert(0, id);
    if (_recIds.length > 10) _recIds = _recIds.sublist(0, 10);
    _savePrefs();
  }

  void _playChannel(Channel ch) {
    if (_emergency) {
      _showSnack('Streaming temporarily unavailable.', isError: true);
      return;
    }
    setState(() => _playingId = ch.id);
    _addRec(ch.id);
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => PlayerScreen(channel: ch)),
    ).then((_) => setState(() => _playingId = null));
  }

  void _showSnack(String msg, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg),
      backgroundColor: isError ? Colors.red : AppTheme.red,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
    ));
  }

  int get _crossAxisCount => _viewMode == 'g2' ? 2 : _viewMode == 'lst' ? 1 : 3;

  @override
  void dispose() {
    _bannerTimer?.cancel();
    _connSub?.cancel();
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = widget.isDark;
    final bg = isDark ? const Color(0xFF06080C) : const Color(0xFFF1F5F9);
    final navBg = isDark ? const Color(0xFF0C0F14) : const Color(0xFFF1F5F9);

    return Scaffold(
      backgroundColor: bg,
      drawer: _buildDrawer(navBg),
      body: Column(
        children: [
          // ── Navbar ──
          _buildNavBar(navBg),

          // ── Offline bar ──
          if (_offline)
            Container(
              width: double.infinity,
              color: const Color(0xFFB45309),
              padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 14),
              child: const Text(
                '⚠ No internet connection',
                style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600),
                textAlign: TextAlign.center,
              ),
            ),

          // ── Body ──
          Expanded(
            child: _searching ? _buildSearchResults() : _buildMain(),
          ),
        ],
      ),
    );
  }

  // ── NAVBAR ──
  Widget _buildNavBar(Color bg) {
    return Container(
      height: 54,
      color: bg.withOpacity(0.95),
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Row(
        children: [
          Builder(builder: (ctx) => GestureDetector(
            onTap: () => Scaffold.of(ctx).openDrawer(),
            child: _NavBtn(child: const Icon(Icons.menu, size: 18)),
          )),
          const SizedBox(width: 11),
          RichText(
            text: TextSpan(
              children: [
                const TextSpan(
                  text: 'QUID',
                  style: TextStyle(color: AppTheme.red, fontSize: 19, fontWeight: FontWeight.w900),
                ),
                TextSpan(
                  text: 'TV',
                  style: TextStyle(
                    color: Theme.of(context).textTheme.bodyLarge?.color,
                    fontSize: 19,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ],
            ),
          ),
          const Spacer(),
          GestureDetector(
            onTap: widget.onThemeToggle,
            child: _NavBtn(child: Icon(widget.isDark ? Icons.light_mode : Icons.dark_mode, size: 18)),
          ),
          const SizedBox(width: 6),
          GestureDetector(
            onTap: () => setState(() { _searching = true; }),
            child: _NavBtn(child: const Icon(Icons.search, size: 18)),
          ),
        ],
      ),
    );
  }

  // ── DRAWER ──
  Widget _buildDrawer(Color bg) {
    return Drawer(
      backgroundColor: bg,
      width: 265,
      child: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  RichText(text: const TextSpan(children: [
                    TextSpan(text: 'QUID', style: TextStyle(color: AppTheme.red, fontSize: 18, fontWeight: FontWeight.w900)),
                    TextSpan(text: 'TV', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w900)),
                  ])),
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: _NavBtn(child: const Icon(Icons.close, size: 18)),
                  ),
                ],
              ),
            ),
            const Divider(height: 1),
            _DrawerSection('BROWSE'),
            _DrawerItem(Icons.grid_view, 'All Channels', _category == 'all', () { _setCategory('all'); Navigator.pop(context); }),
            _DrawerItem(Icons.star, 'Favourites', _category == 'fav', () { _setCategory('fav'); Navigator.pop(context); }),
            _DrawerItem(Icons.history, 'Recently Watched', _category == 'rec', () { _setCategory('rec'); Navigator.pop(context); }),
            const Divider(height: 1),
            _DrawerSection('APPEARANCE'),
            _DrawerItem(Icons.palette, 'Toggle Theme', false, () { widget.onThemeToggle(); Navigator.pop(context); }),
            const Divider(height: 1),
            _DrawerSection('SUPPORT'),
            _DrawerItem(Icons.headset_mic, 'Contact Us', false, () async {
              Navigator.pop(context);
              final url = await _firebase.getContactUrl();
              // launch url if available
            }),
          ],
        ),
      ),
    );
  }

  void _setCategory(String cat) {
    setState(() => _category = cat);
    _applyFilter();
  }

  // ── MAIN CONTENT ──
  Widget _buildMain() {
    return CustomScrollView(
      slivers: [
        // Banner
        if (_banners.isNotEmpty)
          SliverToBoxAdapter(child: _buildBanner()),

        // Notice
        if (_noticeOn && _noticeText != null)
          SliverToBoxAdapter(child: _buildNotice()),

        // Channel header
        SliverToBoxAdapter(child: _buildChannelHeader()),

        // Channel grid
        if (_loading)
          SliverToBoxAdapter(child: _buildSkeletons())
        else if (_filtered.isEmpty)
          SliverToBoxAdapter(child: _buildEmpty())
        else
          _viewMode == 'lst'
              ? SliverList(delegate: SliverChildBuilderDelegate(
                  (_, i) => Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    child: _buildCard(_filtered[i]),
                  ),
                  childCount: _filtered.length,
                ))
              : SliverPadding(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  sliver: SliverGrid(
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: _crossAxisCount,
                      mainAxisSpacing: 10,
                      crossAxisSpacing: 10,
                      childAspectRatio: _viewMode == 'g2' ? 0.85 : 0.78,
                    ),
                    delegate: SliverChildBuilderDelegate(
                      (_, i) => _buildCard(_filtered[i]),
                      childCount: _filtered.length,
                    ),
                  ),
                ),

        const SliverToBoxAdapter(child: SizedBox(height: 90)),
      ],
    );
  }

  Widget _buildCard(Channel ch) {
    return ChannelCard(
      channel: ch,
      isFav: _favIds.contains(ch.id),
      isPlaying: _playingId == ch.id,
      isPinned: ch.pinned,
      viewMode: _viewMode,
      onTap: () => _playChannel(ch),
      onFavTap: () => _toggleFav(ch.id),
    );
  }

  // ── BANNER ──
  Widget _buildBanner() {
    if (_banners.isEmpty) return const SizedBox.shrink();
    final b = _banners[_bannerIdx % _banners.length];
    return Container(
      margin: const EdgeInsets.fromLTRB(12, 10, 12, 0),
      height: MediaQuery.of(context).size.height * 0.22,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        color: const Color(0xFF111620),
        image: b['imageUrl'] != null
            ? DecorationImage(image: NetworkImage(b['imageUrl']), fit: BoxFit.cover)
            : null,
      ),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Colors.transparent, Colors.black.withOpacity(0.7)],
          ),
        ),
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            Row(children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                decoration: BoxDecoration(color: AppTheme.red, borderRadius: BorderRadius.circular(5)),
                child: const Text('LIVE', style: TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 1)),
              ),
              const SizedBox(width: 7),
              const Text('Featured', style: TextStyle(color: Color(0xFF60A5FA), fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 2)),
            ]),
            const SizedBox(height: 7),
            Text(
              b['title']?.toString() ?? 'Premium TV Streaming',
              style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w800),
            ),
          ],
        ),
      ),
    );
  }

  // ── NOTICE ──
  Widget _buildNotice() {
    return Container(
      margin: const EdgeInsets.fromLTRB(12, 8, 12, 0),
      height: 30,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        gradient: const LinearGradient(colors: [Color(0xFF1D4ED8), Color(0xFF2563EB)]),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 11),
            decoration: const BoxDecoration(
              color: Color(0x40000000),
              borderRadius: BorderRadius.only(topLeft: Radius.circular(8), bottomLeft: Radius.circular(8)),
            ),
            child: const Text('NOTICE', style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w800, letterSpacing: 1.5)),
          ),
          Expanded(
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Text(
                _noticeText ?? '',
                style: const TextStyle(color: Colors.white, fontSize: 12),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── CHANNEL HEADER ──
  Widget _buildChannelHeader() {
    final titles = {'all': 'All Channels', 'fav': 'Favourite Channels', 'rec': 'Recently Watched'};
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 14, 12, 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            titles[_category] ?? 'All Channels',
            style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 2.5, color: Colors.grey),
          ),
          Row(children: [
            _ViewBtn(icon: Icons.list, active: _viewMode == 'lst', onTap: () => _setView('lst')),
            const SizedBox(width: 5),
            _ViewBtn(icon: Icons.grid_view, active: _viewMode == 'g2', onTap: () => _setView('g2')),
            const SizedBox(width: 5),
            _ViewBtn(icon: Icons.apps, active: _viewMode == 'g3', onTap: () => _setView('g3')),
          ]),
        ],
      ),
    );
  }

  void _setView(String v) {
    setState(() => _viewMode = v);
    _savePrefs();
  }

  // ── SEARCH ──
  Widget _buildSearchResults() {
    return Column(
      children: [
        // Search bar
        Container(
          color: widget.isDark ? const Color(0xFF0C0F14) : Colors.white,
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
          child: Row(
            children: [
              GestureDetector(
                onTap: () { setState(() { _searching = false; _searchCtrl.clear(); _applyFilter(); }); },
                child: _NavBtn(child: const Icon(Icons.arrow_back, size: 18)),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: TextField(
                  controller: _searchCtrl,
                  autofocus: true,
                  style: const TextStyle(fontSize: 14),
                  decoration: const InputDecoration(
                    hintText: 'Search channels…',
                    border: InputBorder.none,
                    hintStyle: TextStyle(color: Colors.grey),
                  ),
                  onChanged: (_) { _applyFilter(); setState(() {}); },
                ),
              ),
            ],
          ),
        ),
        // Results
        Expanded(
          child: _filtered.isEmpty
              ? const Center(child: Text('No channels found', style: TextStyle(color: Colors.grey)))
              : ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: _filtered.length,
                  itemBuilder: (_, i) => _buildCard(_filtered[i]),
                ),
        ),
      ],
    );
  }

  // ── SKELETONS ──
  Widget _buildSkeletons() {
    return Shimmer.fromColors(
      baseColor: const Color(0xFF1A2030),
      highlightColor: const Color(0xFF253040),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 3,
            mainAxisSpacing: 10,
            crossAxisSpacing: 10,
            childAspectRatio: 0.78,
          ),
          itemCount: 9,
          itemBuilder: (_, __) => Container(
            decoration: BoxDecoration(
              color: const Color(0xFF0F1520),
              borderRadius: BorderRadius.circular(14),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildEmpty() {
    return const Center(
      child: Padding(
        padding: EdgeInsets.all(40),
        child: Column(
          children: [
            Icon(Icons.tv_off, color: Colors.grey, size: 48),
            SizedBox(height: 12),
            Text('No channels found', style: TextStyle(color: Colors.grey)),
          ],
        ),
      ),
    );
  }
}

// ── Small helper widgets ──

class _NavBtn extends StatelessWidget {
  final Widget child;
  const _NavBtn({required this.child});
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 36,
      height: 36,
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.07),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Center(child: child),
    );
  }
}

class _ViewBtn extends StatelessWidget {
  final IconData icon;
  final bool active;
  final VoidCallback onTap;
  const _ViewBtn({required this.icon, required this.active, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 30,
        height: 30,
        decoration: BoxDecoration(
          color: active ? AppTheme.red : Colors.white.withOpacity(0.06),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: active ? AppTheme.red : Colors.white.withOpacity(0.1)),
        ),
        child: Icon(icon, size: 15, color: active ? Colors.white : Colors.grey),
      ),
    );
  }
}

class _DrawerSection extends StatelessWidget {
  final String label;
  const _DrawerSection(this.label);
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 6),
      child: Text(label, style: const TextStyle(fontSize: 9, fontWeight: FontWeight.w800, letterSpacing: 2.5, color: Colors.grey)),
    );
  }
}

class _DrawerItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool active;
  final VoidCallback onTap;
  const _DrawerItem(this.icon, this.label, this.active, this.onTap);
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        color: active ? AppTheme.red.withOpacity(0.1) : Colors.transparent,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 11),
        child: Row(
          children: [
            Icon(icon, size: 16, color: active ? AppTheme.red : Colors.grey),
            const SizedBox(width: 11),
            Text(label, style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500, color: active ? AppTheme.red : null)),
          ],
        ),
      ),
    );
  }
}
