import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:media_kit/media_kit.dart';
import 'package:media_kit_video/media_kit_video.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import '../models/channel.dart';
import '../services/app_theme.dart';

class PlayerScreen extends StatefulWidget {
  final Channel channel;

  const PlayerScreen({super.key, required this.channel});

  @override
  State<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen> {
  late final Player _player;
  late final VideoController _controller;
  bool _isFullscreen = false;
  String _fitLabel = 'Contain';
  BoxFit _fit = BoxFit.contain;
  bool _controlsVisible = true;
  bool _loading = true;
  String _quality = 'Auto';

  @override
  void initState() {
    super.initState();
    WakelockPlus.enable();
    _player = Player();
    _controller = VideoController(_player);
    _player.stream.playing.listen((_) => _hideControlsDelayed());
    _player.stream.buffering.listen((buf) {
      if (mounted) setState(() => _loading = buf);
    });
    _player.stream.tracks.listen((tracks) {
      // Detect quality from video tracks
      final vt = tracks.video;
      if (vt.isNotEmpty && mounted) {
        setState(() => _quality = 'HD');
      }
    });
    _loadChannel();
  }

  void _loadChannel() {
    final url = widget.channel.url;
    _player.open(Media(url));
  }

  void _hideControlsDelayed() {
    Future.delayed(const Duration(seconds: 4), () {
      if (mounted) setState(() => _controlsVisible = false);
    });
  }

  void _toggleControls() {
    setState(() => _controlsVisible = !_controlsVisible);
    if (_controlsVisible) _hideControlsDelayed();
  }

  void _cycleFit() {
    setState(() {
      if (_fit == BoxFit.contain) {
        _fit = BoxFit.cover;
        _fitLabel = 'Cover';
      } else if (_fit == BoxFit.cover) {
        _fit = BoxFit.fill;
        _fitLabel = 'Fill';
      } else {
        _fit = BoxFit.contain;
        _fitLabel = 'Contain';
      }
    });
    _showSnack(_fitLabel);
  }

  void _toggleFullscreen() {
    setState(() => _isFullscreen = !_isFullscreen);
    if (_isFullscreen) {
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
      SystemChrome.setPreferredOrientations([
        DeviceOrientation.landscapeLeft,
        DeviceOrientation.landscapeRight,
      ]);
    } else {
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
      SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
    }
  }

  void _showSnack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        duration: const Duration(seconds: 1),
        backgroundColor: AppTheme.red,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  @override
  void dispose() {
    WakelockPlus.disable();
    _player.dispose();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: GestureDetector(
          onTap: _toggleControls,
          child: Stack(
            fit: StackFit.expand,
            children: [
              // ── Video ──
              Video(
                controller: _controller,
                fit: _fit,
                controls: NoVideoControls,
              ),

              // ── Loading spinner ──
              if (_loading)
                const Center(
                  child: CircularProgressIndicator(
                    color: AppTheme.red,
                    strokeWidth: 2.5,
                  ),
                ),

              // ── Controls overlay ──
              AnimatedOpacity(
                opacity: _controlsVisible ? 1.0 : 0.0,
                duration: const Duration(milliseconds: 220),
                child: IgnorePointer(
                  ignoring: !_controlsVisible,
                  child: Stack(
                    children: [
                      // Top gradient
                      Positioned(
                        top: 0,
                        left: 0,
                        right: 0,
                        height: 80,
                        child: Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: [Colors.black.withOpacity(0.7), Colors.transparent],
                            ),
                          ),
                        ),
                      ),

                      // Bottom gradient
                      Positioned(
                        bottom: 0,
                        left: 0,
                        right: 0,
                        height: 80,
                        child: Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.bottomCenter,
                              end: Alignment.topCenter,
                              colors: [Colors.black.withOpacity(0.7), Colors.transparent],
                            ),
                          ),
                        ),
                      ),

                      // Top bar: channel info + buttons
                      Positioned(
                        top: 10,
                        left: 10,
                        right: 10,
                        child: Row(
                          children: [
                            // Channel logo + name
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                              decoration: BoxDecoration(
                                color: Colors.black.withOpacity(0.55),
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(color: Colors.white.withOpacity(0.12)),
                                backgroundBlendMode: BlendMode.srcOver,
                              ),
                              child: Row(
                                children: [
                                  if (widget.channel.logo != null)
                                    ClipRRect(
                                      borderRadius: BorderRadius.circular(4),
                                      child: Image.network(
                                        widget.channel.logo!,
                                        width: 24,
                                        height: 24,
                                        fit: BoxFit.contain,
                                        errorBuilder: (_, __, ___) => const SizedBox.shrink(),
                                      ),
                                    ),
                                  if (widget.channel.logo != null) const SizedBox(width: 8),
                                  Text(
                                    widget.channel.name,
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 13,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                  const SizedBox(width: 6),
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
                                    decoration: BoxDecoration(
                                      color: AppTheme.red,
                                      borderRadius: BorderRadius.circular(4),
                                    ),
                                    child: const Text(
                                      'LIVE',
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 9,
                                        fontWeight: FontWeight.w900,
                                        letterSpacing: 0.8,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),

                            const Spacer(),

                            // Fit button
                            _PlayerActionBtn(
                              color: const Color(0xFF22C55E).withOpacity(0.75),
                              onTap: _cycleFit,
                              child: const Icon(Icons.crop, color: Colors.white, size: 16),
                            ),
                            const SizedBox(width: 6),

                            // Fullscreen button
                            _PlayerActionBtn(
                              color: const Color(0xFF3B82F6).withOpacity(0.75),
                              onTap: _toggleFullscreen,
                              child: Icon(
                                _isFullscreen ? Icons.fullscreen_exit : Icons.fullscreen,
                                color: Colors.white,
                                size: 18,
                              ),
                            ),
                            const SizedBox(width: 6),

                            // Close button
                            _PlayerActionBtn(
                              color: AppTheme.red.withOpacity(0.75),
                              onTap: () => Navigator.pop(context),
                              child: const Icon(Icons.close, color: Colors.white, size: 16),
                            ),
                          ],
                        ),
                      ),

                      // Center play/pause + volume row
                      Center(
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                          decoration: BoxDecoration(
                            color: Colors.black.withOpacity(0.7),
                            borderRadius: BorderRadius.circular(40),
                            border: Border.all(color: Colors.white.withOpacity(0.12)),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              // Rewind 10s
                              _CenterBtn(
                                onTap: () => _player.seek(
                                  Duration(seconds: _player.state.position.inSeconds - 10),
                                ),
                                child: const Icon(Icons.replay_10, color: Colors.white, size: 22),
                              ),
                              const SizedBox(width: 6),

                              // Play/Pause
                              StreamBuilder<bool>(
                                stream: _player.stream.playing,
                                builder: (ctx, snap) {
                                  final playing = snap.data ?? false;
                                  return GestureDetector(
                                    onTap: () => _player.playOrPause(),
                                    child: Container(
                                      width: 48,
                                      height: 48,
                                      decoration: const BoxDecoration(
                                        color: AppTheme.red,
                                        shape: BoxShape.circle,
                                      ),
                                      child: Icon(
                                        playing ? Icons.pause : Icons.play_arrow,
                                        color: Colors.white,
                                        size: 26,
                                      ),
                                    ),
                                  );
                                },
                              ),
                              const SizedBox(width: 6),

                              // Forward 10s
                              _CenterBtn(
                                onTap: () => _player.seek(
                                  Duration(seconds: _player.state.position.inSeconds + 10),
                                ),
                                child: const Icon(Icons.forward_10, color: Colors.white, size: 22),
                              ),

                              const SizedBox(width: 8),

                              // Volume icon
                              const Icon(Icons.volume_up, color: Colors.white54, size: 16),
                              const SizedBox(width: 4),

                              // Volume slider
                              StreamBuilder<double>(
                                stream: _player.stream.volume,
                                builder: (ctx, snap) {
                                  return SizedBox(
                                    width: 70,
                                    child: SliderTheme(
                                      data: SliderTheme.of(ctx).copyWith(
                                        trackHeight: 2.5,
                                        thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 6),
                                        overlayShape: SliderComponentShape.noOverlay,
                                        activeTrackColor: Colors.white,
                                        inactiveTrackColor: Colors.white24,
                                        thumbColor: Colors.white,
                                      ),
                                      child: Slider(
                                        value: (snap.data ?? 100) / 100,
                                        onChanged: (v) => _player.setVolume(v * 100),
                                      ),
                                    ),
                                  );
                                },
                              ),
                            ],
                          ),
                        ),
                      ),

                      // Bottom progress bar
                      Positioned(
                        bottom: 0,
                        left: 0,
                        right: 0,
                        child: StreamBuilder<Duration>(
                          stream: _player.stream.position,
                          builder: (ctx, posSnap) {
                            return StreamBuilder<Duration>(
                              stream: _player.stream.duration,
                              builder: (ctx2, durSnap) {
                                final pos = posSnap.data ?? Duration.zero;
                                final dur = durSnap.data ?? Duration.zero;
                                final isLive = dur == Duration.zero;
                                final progress = (!isLive && dur.inMilliseconds > 0)
                                    ? pos.inMilliseconds / dur.inMilliseconds
                                    : 0.0;

                                return Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                      begin: Alignment.bottomCenter,
                                      end: Alignment.topCenter,
                                      colors: [Colors.black.withOpacity(0.7), Colors.transparent],
                                    ),
                                  ),
                                  child: Row(
                                    children: [
                                      Text(
                                        isLive ? 'Live' : _fmt(pos),
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontSize: 11,
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                      const SizedBox(width: 8),
                                      Expanded(
                                        child: isLive
                                            ? Container(height: 2.5, color: AppTheme.red)
                                            : SliderTheme(
                                                data: SliderTheme.of(ctx).copyWith(
                                                  trackHeight: 2.5,
                                                  thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 6),
                                                  overlayShape: SliderComponentShape.noOverlay,
                                                  activeTrackColor: AppTheme.red,
                                                  inactiveTrackColor: Colors.white22,
                                                  thumbColor: Colors.white,
                                                ),
                                                child: Slider(
                                                  value: progress.clamp(0.0, 1.0),
                                                  onChanged: (v) => _player.seek(
                                                    Duration(milliseconds: (v * dur.inMilliseconds).toInt()),
                                                  ),
                                                ),
                                              ),
                                      ),
                                      if (!isLive) ...[
                                        const SizedBox(width: 8),
                                        Text(
                                          _fmt(dur),
                                          style: const TextStyle(
                                            color: Colors.white,
                                            fontSize: 11,
                                            fontWeight: FontWeight.w600,
                                          ),
                                        ),
                                      ],
                                    ],
                                  ),
                                );
                              },
                            );
                          },
                        ),
                      ),

                      // Quality badge
                      Positioned(
                        top: 10,
                        left: 10 + 180,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.09),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Text(
                            _quality,
                            style: const TextStyle(
                              color: Colors.white60,
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _fmt(Duration d) {
    final m = d.inMinutes;
    final s = d.inSeconds % 60;
    return '$m:${s.toString().padLeft(2, '0')}';
  }
}

// ── Helper Widgets ──

class _PlayerActionBtn extends StatelessWidget {
  final Color color;
  final VoidCallback onTap;
  final Widget child;

  const _PlayerActionBtn({required this.color, required this.onTap, required this.child});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 38,
        height: 38,
        decoration: BoxDecoration(
          color: color,
          shape: BoxShape.circle,
          border: Border.all(color: Colors.white.withOpacity(0.14)),
        ),
        child: Center(child: child),
      ),
    );
  }
}

class _CenterBtn extends StatelessWidget {
  final VoidCallback onTap;
  final Widget child;

  const _CenterBtn({required this.onTap, required this.child});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 38,
        height: 38,
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.1),
          shape: BoxShape.circle,
        ),
        child: Center(child: child),
      ),
    );
  }
}
