import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  static const Color red = Color(0xFFE50914);
  static const Color red2 = Color(0xFFFF3B30);

  static ThemeData dark() {
    return ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: const Color(0xFF06080C),
      colorScheme: const ColorScheme.dark(
        primary: red,
        surface: Color(0xFF0C0F14),
        surfaceContainerHighest: Color(0xFF111620),
      ),
      textTheme: GoogleFonts.outfitTextTheme(ThemeData.dark().textTheme),
      cardColor: const Color(0xFF0F1520),
      dividerColor: Colors.white.withOpacity(0.07),
    );
  }

  static ThemeData light() {
    return ThemeData(
      brightness: Brightness.light,
      scaffoldBackgroundColor: const Color(0xFFF1F5F9),
      colorScheme: const ColorScheme.light(
        primary: red,
        surface: Color(0xFFE8EDF4),
        surfaceContainerHighest: Color(0xFFDDE3EC),
      ),
      textTheme: GoogleFonts.outfitTextTheme(ThemeData.light().textTheme),
      cardColor: Colors.white,
      dividerColor: Colors.black.withOpacity(0.08),
    );
  }
}
