import 'package:firebase_database/firebase_database.dart';
import '../models/channel.dart';

class FirebaseService {
  final _db = FirebaseDatabase.instance;

  // Firebase config (same as QuidTV web)
  static const String _firebaseUrl =
      'https://live-tv-sever-default-rtdb.asia-southeast1.firebasedatabase.app';

  Stream<List<Channel>> channelsStream() {
    return _db.ref('channels').onValue.map((event) {
      final data = event.snapshot.value;
      if (data == null) return <Channel>[];
      final map = data as Map<dynamic, dynamic>;
      return map.entries
          .map((e) => Channel.fromMap(e.key.toString(), e.value as Map))
          .toList()
        ..sort((a, b) {
          if (a.pinned && !b.pinned) return -1;
          if (!a.pinned && b.pinned) return 1;
          return a.name.compareTo(b.name);
        });
    });
  }

  Stream<Map<String, dynamic>?> noticeStream() {
    return _db.ref('noticeSettings').onValue.map((event) {
      final data = event.snapshot.value;
      if (data == null) return null;
      return Map<String, dynamic>.from(data as Map);
    });
  }

  Stream<List<Map<String, dynamic>>> bannersStream() {
    return _db.ref('banners').onValue.map((event) {
      final data = event.snapshot.value;
      if (data == null) return <Map<String, dynamic>>[];
      final map = data as Map<dynamic, dynamic>;
      final list = map.entries
          .map((e) => {'id': e.key.toString(), ...Map<String, dynamic>.from(e.value as Map)})
          .toList();
      list.sort((a, b) => ((a['order'] ?? 0) as int).compareTo((b['order'] ?? 0) as int));
      return list;
    });
  }

  Stream<List<Map<String, dynamic>>> adsStream() {
    return _db.ref('advertisements').onValue.map((event) {
      final data = event.snapshot.value;
      if (data == null) return <Map<String, dynamic>>[];
      final map = data as Map<dynamic, dynamic>;
      return map.entries
          .where((e) => (e.value as Map)['status'] == 'active')
          .map((e) => {'id': e.key.toString(), ...Map<String, dynamic>.from(e.value as Map)})
          .toList();
    });
  }

  Stream<bool> emergencyStream() {
    return _db.ref('emergencyStop').onValue.map((event) {
      final data = event.snapshot.value;
      if (data == null) return false;
      return (data as Map)['active'] == true;
    });
  }

  Future<String?> getContactUrl() async {
    final snap = await _db.ref('contact').get();
    if (snap.value == null) return null;
    return (snap.value as Map)['url']?.toString();
  }

  void incrementLike(String channelId) {
    _db.ref('channels/$channelId/likes').runTransaction((value) {
      return Transaction.success((value as int? ?? 0) + 1);
    });
  }

  void recordAdView(String adId) {
    _db.ref('advertisements/$adId/views').runTransaction((v) {
      return Transaction.success((v as int? ?? 0) + 1);
    });
  }

  void recordAdClick(String adId) {
    _db.ref('advertisements/$adId/clicks').runTransaction((v) {
      return Transaction.success((v as int? ?? 0) + 1);
    });
    _db.ref('advertisements/$adId/lastClicked').set(DateTime.now().millisecondsSinceEpoch);
  }
}
